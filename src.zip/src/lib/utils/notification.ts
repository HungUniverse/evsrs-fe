const requestPermission = async () => {
  await Notification.requestPermission();
};
export default requestPermission;
