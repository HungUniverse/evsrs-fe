import type { Depot } from "./car/depot";
import type { DateString } from "./common/pagination";

export type RoleCode = "ADMIN" | "USER" | "STAFF";

export interface User {
  id?: string; // optional: lấy từ nhiều claim khác nhau
  userId?: string; // primary id
  name?: string;
  email?: string;
  phone?: string;
  role: RoleCode;
  avatar?: string;
  userName?: string;
}

export interface UserFull {
  id: string; // từ API
  userId: string; // alias = id (để UI cũ vẫn dùng được)
  userName: string;
  userEmail: string;
  phoneNumber: string | null;
  fullName: string;
  profilePicture?: string;
  role: RoleCode;
  depotId?: string;
  depot?: Depot;
  dateOfBirth: string;
  isVerify: boolean;
  isDeleted: boolean;
  createdAt: string;
  updatedAt: string;
  createdBy: string | null;
  updatedBy: string | null;
}
export interface UserResponse {
  id: string;
  userId: string;
  userName: string;
  userEmail: string;
  phoneNumber: string | null;
  fullName: string | null;
  profilePicture?: string;
  depotId?: string;
  depot?: Depot;
  role: RoleCode;
  dateOfBirth: string;
  isVerify: boolean;
  isDeleted: boolean;
  createdAt: string;
  updatedAt: string;
  createdBy: string | null;
  updatedBy: string | null;
}
export interface UserAtDepotRequest {
  userEmail: string;
  password: string;
  fullName: string;
  phoneNumber: string;
  frontImage: string;
  backImage: string;
  countryCode: string;
  numberMasked: string;
  licenseClass: string;
  expiredAt: DateString;
}
export interface UserAtDepotResponse {
  userId: string;
  userEmail: string;
  fullName: string;
  phoneNumber: string;
}
export interface StaffRequest {
  userName: string;
  userEmail: string;
  fullName: string;
  phoneNumber: string;
  depotId: string;
  dateOfBirth: string;
  profilePicture: string;
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
}

export interface LoginRequest {
  identifier: string;
  password: string;
  notificationToken?: string;
}

export interface LoginResponse {
  accessToken: string;
  refreshToken: string;
}

export interface RefreshTokenResponse {
  accessToken: string;
  refreshToken?: string;
}

export interface LogoutBody {
  refreshToken: string;
}
