import type { Contract } from "@/@types/contract";
import { mockUsers } from "./mock-user";

// Users — nguồn dữ liệu cho phần lessee + cccd/gplx
const userU3 = mockUsers.find((u) => u.id === "u3")!;
const userU4 = mockUsers.find((u) => u.id === "u4")!;
const userU5 = mockUsers.find((u) => u.id === "u5")!;

function calcDeposit(dailyRate: number, days: number, percent = 0.4) {
  return Math.round(dailyRate * days * percent);
}
function calcRemaining(total: number, deposit: number) {
  return Math.max(total - deposit, 0);
}

export const mockContracts: Contract[] = [
  {
    orderId: "12A23DD1",
    title: "HỢP ĐỒNG THUÊ & NHẬN XE Ô TÔ ĐIỆN",
    contractNumber: "12A23DD1",
    contractDate: "2025-01-10",
    lessorCompanyName: "Công ty TNHH ECORENT VIỆT NAM",
    lessorAddress: "01 Nguyễn Văn Việt, Quận 9, TP.HCM",
    lessorPhone: "0900000001",
    lessorEmail: "info@ecorent.com",

    lessorId: userU3.id,
    lesseeFullName: userU3.fullName,
    lesseeIdNumber: userU3.cccd,
    lesseePhone: userU3.phoneNumber,
    lesseeAddress: "",
    lesseeDateOfBirth: userU3.dob,
    lesseeEmail: userU3.email,

    gplx: userU3.gplx,
    cccd: userU3.cccd,

    vehicleCode: "VF8",
    licensePlates: "51H-123.45",
    rentalDays: 3,
    rentalStartDate: "2025-01-10",
    rentalEndDate: "2025-01-13",
    pickupAddress: "01 Nguyễn Trọng Quyền, Quận 7, TP.HCM",
    dailyRate: 800000,
    vatRate: 10,
    overMileageFee: "5.000 - 10.000 VNĐ/km",
    carWashFee: "50.000 - 200.000 VNĐ/lần",

    depositAmount: calcDeposit(800000, 3),
    totalPayment: 2400000,
    remainingAmount: calcRemaining(2400000, calcDeposit(800000, 3)),

    status: "cancelled",
    createdAt: "2025-01-10T10:00:00Z",
    updatedAt: "2025-01-10T10:00:00Z",
  },
  {
    orderId: "12A23DD2",
    title: "HỢP ĐỒNG THUÊ & NHẬN XE Ô TÔ ĐIỆN",
    contractNumber: "12A23DD2",
    contractDate: "2025-01-11",
    lessorCompanyName: "Công ty TNHH ECORENT VIỆT NAM",
    lessorAddress: "01 Nguyễn Văn Việt, Quận 9, TP.HCM",
    lessorPhone: "0900000001",
    lessorEmail: "info@ecorent.com",

    lessorId: userU3.id,
    lesseeFullName: userU3.fullName,
    lesseeIdNumber: userU3.cccd,
    lesseePhone: userU3.phoneNumber,
    lesseeAddress: "",
    lesseeDateOfBirth: userU3.dob,
    lesseeEmail: userU3.email,

    gplx: userU3.gplx,
    cccd: userU3.cccd,

    vehicleCode: "VF5",
    licensePlates: "51H-678.90",
    rentalDays: 7,
    rentalStartDate: "2025-01-11",
    rentalEndDate: "2025-01-18",
    pickupAddress: "02 Lê Văn Việt, Quận 9, TP.HCM",
    dailyRate: 600000,
    vatRate: 10,
    overMileageFee: "3.000 - 8.000 VNĐ/km",
    carWashFee: "30.000 - 150.000 VNĐ/lần",

    depositAmount: calcDeposit(600000, 7),
    totalPayment: 4200000,
    remainingAmount: calcRemaining(4200000, calcDeposit(600000, 7)),

    status: "confirmed",
    createdAt: "2025-01-11T09:00:00Z",
    updatedAt: "2025-01-11T09:00:00Z",
  },
  {
    orderId: "12A23DD3",
    title: "HỢP ĐỒNG THUÊ & NHẬN XE Ô TÔ ĐIỆN",
    contractNumber: "12A23DD3",
    contractDate: "2025-01-12",
    lessorCompanyName: "Công ty TNHH ECORENT VIỆT NAM",
    lessorAddress: "01 Nguyễn Văn Việt, Quận 9, TP.HCM",
    lessorPhone: "0900000001",
    lessorEmail: "info@ecorent.com",

    lessorId: userU3.id,
    lesseeFullName: userU3.fullName,
    lesseeIdNumber: userU3.cccd,
    lesseePhone: userU3.phoneNumber,
    lesseeAddress: "",
    lesseeDateOfBirth: userU3.dob,
    lesseeEmail: userU3.email,

    gplx: userU3.gplx,
    cccd: userU3.cccd,

    vehicleCode: "VF7",
    licensePlates: "51H-999.88",
    rentalDays: 1,
    rentalStartDate: "2025-01-12",
    rentalEndDate: "2025-01-13",
    pickupAddress: "03 Nguyễn Thị Minh Khai, Quận 1, TP.HCM",
    dailyRate: 1000000,
    vatRate: 10,
    overMileageFee: "8.000 - 15.000 VNĐ/km",
    carWashFee: "80.000 - 300.000 VNĐ/lần",

    depositAmount: calcDeposit(1000000, 1),
    totalPayment: 1000000, // đã gồm VAT theo mock hiện tại
    remainingAmount: calcRemaining(1000000, calcDeposit(1000000, 1)),

    status: "completed",
    createdAt: "2025-01-12T14:00:00Z",
    updatedAt: "2025-01-13T18:00:00Z",
  },
  {
    orderId: "12A23DD4",
    title: "HỢP ĐỒNG THUÊ & NHẬN XE Ô TÔ ĐIỆN",
    contractNumber: "12A23DD4",
    contractDate: "2025-01-14",
    lessorCompanyName: "Công ty TNHH ECORENT VIỆT NAM",
    lessorAddress: "01 Nguyễn Văn Việt, Quận 9, TP.HCM",
    lessorPhone: "0900000001",
    lessorEmail: "info@ecorent.com",

    lessorId: userU3.id,
    lesseeFullName: userU3.fullName,
    lesseeIdNumber: userU3.cccd,
    lesseePhone: userU3.phoneNumber,
    lesseeAddress: "",
    lesseeDateOfBirth: userU3.dob,
    lesseeEmail: userU3.email,

    gplx: userU3.gplx,
    cccd: userU3.cccd,

    vehicleCode: "VF9",
    licensePlates: "51H-888.77",
    rentalDays: 5,
    rentalStartDate: "2025-01-15",
    rentalEndDate: "2025-01-20",
    pickupAddress: "05 Phan Xích Long, Quận Phú Nhuận, TP.HCM",
    dailyRate: 900000,
    vatRate: 10,
    overMileageFee: "4.000 - 9.000 VNĐ/km",
    carWashFee: "40.000 - 180.000 VNĐ/lần",

    depositAmount: calcDeposit(900000, 5),
    totalPayment: 4950000, // đã gồm VAT theo mock hiện tại
    remainingAmount: calcRemaining(4950000, calcDeposit(900000, 5)),

    status: "confirmed",
    createdAt: "2025-01-14T08:30:00Z",
    updatedAt: "2025-01-14T08:30:00Z",
  },
  // Contracts for user u4
  {
    orderId: "12A23DD5",
    title: "HỢP ĐỒNG THUÊ & NHẬN XE Ô TÔ ĐIỆN",
    contractNumber: "12A23DD5",
    contractDate: "2025-01-16",
    lessorCompanyName: "Công ty TNHH ECORENT VIỆT NAM",
    lessorAddress: "01 Nguyễn Văn Việt, Quận 9, TP.HCM",
    lessorPhone: "0900000001",
    lessorEmail: "info@ecorent.com",

    lessorId: userU4.id,
    lesseeFullName: userU4.fullName,
    lesseeIdNumber: userU4.cccd,
    lesseePhone: userU4.phoneNumber,
    lesseeAddress: "",
    lesseeDateOfBirth: userU4.dob,
    lesseeEmail: userU4.email,

    gplx: userU4.gplx,
    cccd: userU4.cccd,

    vehicleCode: "HONDA-CIVIC",
    licensePlates: "51H-111.22",
    rentalDays: 2,
    rentalStartDate: "2025-01-16",
    rentalEndDate: "2025-01-18",
    pickupAddress: "06 Lê Lợi, Quận 1, TP.HCM",
    dailyRate: 700000,
    vatRate: 10,
    overMileageFee: "6.000 - 12.000 VNĐ/km",
    carWashFee: "60.000 - 250.000 VNĐ/lần",

    depositAmount: calcDeposit(700000, 2),
    totalPayment: 1540000, // đã gồm VAT theo mock hiện tại
    remainingAmount: calcRemaining(1540000, calcDeposit(700000, 2)),

    status: "completed",
    createdAt: "2025-01-16T11:00:00Z",
    updatedAt: "2025-01-16T11:00:00Z",
  },
  {
    orderId: "12A23DD6",
    title: "HỢP ĐỒNG THUÊ & NHẬN XE Ô TÔ ĐIỆN",
    contractNumber: "12A23DD6",
    contractDate: "2025-01-17",
    lessorCompanyName: "Công ty TNHH ECORENT VIỆT NAM",
    lessorAddress: "01 Nguyễn Văn Việt, Quận 9, TP.HCM",
    lessorPhone: "0900000001",
    lessorEmail: "info@ecorent.com",

    lessorId: userU5.id,
    lesseeFullName: userU5.fullName,
    lesseeIdNumber: userU5.cccd,
    lesseePhone: userU5.phoneNumber,
    lesseeAddress: "",
    lesseeDateOfBirth: userU5.dob,
    lesseeEmail: userU5.email,

    gplx: userU5.gplx,
    cccd: userU5.cccd,

    vehicleCode: "TOYOTA-CAMRY",
    licensePlates: "51H-333.44",
    rentalDays: 4,
    rentalStartDate: "2025-01-17",
    rentalEndDate: "2025-01-21",
    pickupAddress: "07 Nguyễn Huệ, Quận 1, TP.HCM",
    dailyRate: 1200000,
    vatRate: 10,
    overMileageFee: "10.000 - 20.000 VNĐ/km",
    carWashFee: "100.000 - 400.000 VNĐ/lần",

    depositAmount: calcDeposit(1200000, 4),
    totalPayment: 5280000, // đã gồm VAT theo mock hiện tại
    remainingAmount: calcRemaining(5280000, calcDeposit(1200000, 4)),

    status: "completed",
    createdAt: "2025-01-17T13:30:00Z",
    updatedAt: "2025-01-21T16:00:00Z",
  },
  {
    orderId: "12A23DD7",
    title: "HỢP ĐỒNG THUÊ & NHẬN XE Ô TÔ ĐIỆN",
    contractNumber: "12A23DD7",
    contractDate: "2025-01-18",
    lessorCompanyName: "Công ty TNHH ECORENT VIỆT NAM",
    lessorAddress: "01 Nguyễn Văn Việt, Quận 9, TP.HCM",
    lessorPhone: "0900000001",
    lessorEmail: "info@ecorent.com",

    lessorId: userU4.id,
    lesseeFullName: userU4.fullName,
    lesseeIdNumber: userU4.cccd,
    lesseePhone: userU4.phoneNumber,
    lesseeAddress: "",
    lesseeDateOfBirth: userU4.dob,
    lesseeEmail: userU4.email,

    gplx: userU4.gplx,
    cccd: userU4.cccd,

    vehicleCode: "HYUNDAI-ACCENT",
    licensePlates: "51H-555.66",
    rentalDays: 1,
    rentalStartDate: "2025-01-18",
    rentalEndDate: "2025-01-19",
    pickupAddress: "08 Điện Biên Phủ, Quận Bình Thạnh, TP.HCM",
    dailyRate: 550000,
    vatRate: 10,
    overMileageFee: "4.000 - 8.000 VNĐ/km",
    carWashFee: "40.000 - 150.000 VNĐ/lần",

    // ✅ sửa lại để dùng công thức
    depositAmount: calcDeposit(550000, 1),
    totalPayment: 605000, // đã gồm VAT theo mock hiện tại
    remainingAmount: calcRemaining(605000, calcDeposit(550000, 1)),

    status: "cancelled",
    createdAt: "2025-01-18T09:15:00Z",
    updatedAt: "2025-01-18T14:30:00Z",
  },
];
