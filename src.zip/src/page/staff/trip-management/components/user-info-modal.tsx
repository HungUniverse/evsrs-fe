import { useEffect, useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { UserFullAPI } from "@/apis/user.api";
import type { UserFull } from "@/@types/auth.type";

type Props = {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  userId: string | null; // có thể dùng cho lessor hoặc lessee
};

export default function UserInfoModal({ open, onOpenChange, userId }: Props) {
  const [user, setUser] = useState<UserFull | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!userId) return;
    
    const loadUser = async () => {
      setLoading(true);
      try {
        console.log("[UserInfoModal] Loading user:", userId);
        const res = await UserFullAPI.getById(userId);
        console.log("[UserInfoModal] User response:", res);
        setUser(res);
      } catch (e: any) {
        console.error("[UserInfoModal] Load error:", e);
        console.error("[UserInfoModal] Error details:", e?.response?.data);
        setUser(null);
      } finally {
        setLoading(false);
      }
    };

    loadUser();
  }, [userId]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl w-[90vw] h-[80vh] p-0 overflow-hidden">
        <DialogHeader className="border-b p-4">
          <DialogTitle>Thông tin người dùng</DialogTitle>
        </DialogHeader>

        <ScrollArea className="h-[calc(80vh-64px)] p-6">
          {loading && (
            <div className="text-center text-slate-500">
              Đang tải thông tin...
            </div>
          )}

          {!loading && !user && (
            <div className="text-center text-slate-500">
              Không tìm thấy người dùng tương ứng.
            </div>
          )}

          {!loading && user && (
            <div className="space-y-6">
              {/* Avatar + thông tin cơ bản */}
              <section className="flex items-center gap-4">
                <img
                  src={user.avatar || "/placeholder-avatar.png"}
                  alt={user.name || user.userName || "User"}
                  className="w-24 h-24 rounded-full border object-cover"
                />
                <div>
                  <div className="text-lg font-semibold">{user.name || user.userName || "—"}</div>
                  <p className="text-sm text-slate-600">{user.email || "—"}</p>
                  <p className="text-sm text-slate-600">{user.phone || "—"}</p>
                  <p className="text-sm text-slate-600">
                    Role: {user.role}
                  </p>
                  {user.dob && (
                    <p className="text-sm text-slate-600">
                      Ngày sinh: {user.dob}
                    </p>
                  )}
                </div>
              </section>

              {/* Thông tin tài khoản */}
              <section className="border rounded-xl p-4 space-y-3">
                <div className="font-medium text-slate-700">
                  Thông tin tài khoản
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <Info label="User ID" value={user.userId || user.id} />
                  <Info label="Username" value={user.userName} />
                  <Info label="Email" value={user.email} />
                  <Info label="Phone" value={user.phone} />
                </div>
              </section>

              {/* Note về thông tin bổ sung */}
              <section className="border rounded-xl p-4 space-y-3">
                <div className="font-medium text-slate-700">
                  Thông tin bổ sung
                </div>
                <div className="text-sm text-slate-500">
                  Thông tin chi tiết như CCCD, GPLX sẽ được hiển thị khi có API tương ứng.
                </div>
              </section>
            </div>
          )}
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}

/* Sub Components */
function Info({ label, value }: { label: string; value?: string }) {
  return (
    <div>
      <p className="text-sm text-slate-500">{label}</p>
      <p className="font-medium">{value || "—"}</p>
    </div>
  );
}

