import React from "react";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Search, Filter, Plus } from "lucide-react";
import type { SortValue } from "../hooks/use-model-table-state";
import type { CarManufacture } from "@/@types/car/carManufacture";
import type { Depot } from "@/@types/car/depot";

interface FilterBarProps {
  search: string;
  onSearchChange: (v: string) => void;
  sort: SortValue;
  onSortChange: (v: SortValue) => void;
  manufacturerCarId: string;
  onManufacturerChange: (v: string) => void;
  depotId: string;
  onDepotChange: (v: string) => void;
  manufacturers: CarManufacture[];
  depots: Depot[];
  onAdd: () => void;
}

const FilterBar: React.FC<FilterBarProps> = ({
  search,
  onSearchChange,
  sort,
  onSortChange,
  manufacturerCarId,
  onManufacturerChange,
  depotId,
  onDepotChange,
  manufacturers,
  depots,
  onAdd,
}) => {
  return (
    <Card className="shadow-sm border bg-muted/30 rounded-lg">
      <CardContent className="p-4">
        {/* Header with Filter Icon and Title */}
        <div className="flex items-center gap-2 mb-3">
          <Filter className="h-4 w-4 text-foreground" />
          <span className="text-sm font-semibold text-foreground">Bộ lọc tìm kiếm</span>
        </div>

        {/* Horizontal Filters Row - Compact Layout */}
        <div className="flex flex-wrap items-center gap-2.5">
          {/* Filters Section - Left Side */}
          <div className="flex flex-wrap items-center gap-2.5 flex-1">
            {/* Search Input */}
            <div className="flex-1 min-w-[150px] max-w-[220px]">
              <div className="relative">
                <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground z-10" />
                <Input
                  value={search}
                  onChange={(e) => onSearchChange(e.target.value)}
                  placeholder="Tên model"
                  className="pl-8 h-9 bg-background text-sm"
                />
              </div>
            </div>

            {/* Manufacturer Filter */}
            <div className="flex-1 min-w-[160px] max-w-[220px]">
              <Select value={manufacturerCarId || "all"} onValueChange={(v) => onManufacturerChange(v === "all" ? "" : v)}>
                <SelectTrigger className="h-9 bg-background text-sm">
                  <SelectValue placeholder="Tất cả nhà sản xuất" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tất cả nhà sản xuất</SelectItem>
                  {manufacturers.map((m) => (
                    <SelectItem key={m.id} value={String(m.id)}>
                      {m.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Depot Filter */}
            <div className="flex-1 min-w-[160px] max-w-[220px]">
              <Select value={depotId || "all"} onValueChange={(v) => onDepotChange(v === "all" ? "" : v)}>
                <SelectTrigger className="h-9 bg-background text-sm">
                  <SelectValue placeholder="Tất cả trạm" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tất cả trạm</SelectItem>
                  {depots.map((d) => (
                    <SelectItem key={d.id} value={String(d.id)}>
                      {d.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Sort Select */}
            <div className="flex-1 min-w-[160px] max-w-[220px]">
              <Select value={sort} onValueChange={(v) => onSortChange(v as SortValue)}>
                <SelectTrigger className="h-9 bg-background text-sm">
                  <SelectValue placeholder="Ngày tạo (mới nhất)" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="name-asc">Tên A-Z</SelectItem>
                  <SelectItem value="name-desc">Tên Z-A</SelectItem>
                  <SelectItem value="price-asc">Giá thấp đến cao</SelectItem>
                  <SelectItem value="price-desc">Giá cao đến thấp</SelectItem>
                  <SelectItem value="range-asc">Tầm hoạt động (thấp đến cao)</SelectItem>
                  <SelectItem value="range-desc">Tầm hoạt động (cao đến thấp)</SelectItem>
                  <SelectItem value="created-desc">Ngày tạo (mới nhất)</SelectItem>
                  <SelectItem value="created-asc">Ngày tạo (cũ nhất)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Add Button - Right Side */}
          <Button onClick={onAdd} className="h-9 shrink-0 text-sm ml-auto bg-emerald-200 text-emerald-900 hover:bg-emerald-300">
            <Plus className="h-3.5 w-3.5 mr-1.5" />
            Thêm model xe
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default FilterBar;
