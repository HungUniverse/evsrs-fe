import { Table, TableBody, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import type { TransactionResponse } from "@/@types/payment/transaction";
import { TransactionTableRow } from "./transaction-row";
import { CreditCard } from "lucide-react";
import { TableCell } from "@/components/ui/table";
import type { UserFull } from "@/@types/auth.type";
import type { OrderBookingDetail } from "@/@types/order/order-booking";

interface TransactionTableProps {
  transactions: TransactionResponse[];
  loading: boolean;
  onViewDetails: (transaction: TransactionResponse) => void;
  onViewUser: (userId: string) => void;
  onViewOrder: (orderId: string) => void;
  usersMap: Map<string, UserFull>;
  ordersMap: Map<string, OrderBookingDetail>;
  startIndex?: number;
}

export function TransactionTable({
  transactions,
  loading,
  onViewDetails,
  onViewUser,
  onViewOrder,
  usersMap,
  ordersMap,
  startIndex = 1,
}: TransactionTableProps) {
  return (
    <div className="rounded-lg border bg-white shadow-sm overflow-x-auto">
      <Table>
        <TableHeader className="bg-[#D1FAE5]">
          <TableRow>
            <TableHead className="w-16 whitespace-nowrap text-[#065F46] text-center sticky left-0 bg-[#D1FAE5] shadow-[4px_0_6px_-2px_rgba(0,0,0,0.1)] z-10">
              STT
            </TableHead>
            <TableHead className="whitespace-nowrap text-[#065F46] sticky left-16 bg-[#D1FAE5] shadow-[4px_0_6px_-2px_rgba(0,0,0,0.1)] z-10">
              Mã giao dịch
            </TableHead>
            <TableHead className="whitespace-nowrap text-[#065F46]">Ngày giao dịch</TableHead>
            <TableHead className="whitespace-nowrap text-[#065F46]">Người dùng</TableHead>
            <TableHead className="whitespace-nowrap text-[#065F46]">Mã đơn hàng</TableHead>
            <TableHead className="whitespace-nowrap text-[#065F46]">Trạng thái</TableHead>
            <TableHead className="whitespace-nowrap text-[#065F46]">Số tiền</TableHead>
            <TableHead className="whitespace-nowrap text-[#065F46]">Mã tham chiếu</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {loading ? (
            <TableRow>
              <TableCell colSpan={8} className="text-center py-8">
                <div className="flex items-center justify-center gap-2 text-muted-foreground">
                  <div className="w-4 h-4 border-2 border-gray-300 border-t-blue-500 rounded-full animate-spin" />
                  <span>Đang tải...</span>
                </div>
              </TableCell>
            </TableRow>
          ) : transactions.length === 0 ? (
            <TableRow>
              <TableCell colSpan={8} className="text-center py-12">
                <div className="flex flex-col items-center gap-3 text-muted-foreground">
                  <CreditCard className="size-8" />
                  <div>
                    <p className="text-sm font-semibold">Chưa có giao dịch nào</p>
                    <p className="text-xs">Không có dữ liệu giao dịch để hiển thị.</p>
                  </div>
                </div>
              </TableCell>
            </TableRow>
          ) : (
            transactions.map((transaction, index) => (
              <TransactionTableRow
                key={transaction.id}
                transaction={transaction}
                onViewDetails={onViewDetails}
                onViewUser={onViewUser}
                onViewOrder={onViewOrder}
                user={usersMap.get(transaction.userId)}
                order={ordersMap.get(transaction.orderBookingId)}
                index={startIndex + index}
              />
            ))
          )}
        </TableBody>
      </Table>
    </div>
  );
}

