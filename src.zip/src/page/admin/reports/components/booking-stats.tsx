import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { mockRecentBookings } from "@/mockdata/mock-admin";

export function BookingStats() {
  const totalBookings = mockRecentBookings.length;
  const confirmedBookings = mockRecentBookings.filter(b => b.status === 'confirmed').length;
  const ongoingBookings = mockRecentBookings.filter(b => b.status === 'ongoing').length;
  const completedBookings = mockRecentBookings.filter(b => b.status === 'completed').length;
  const cancelledBookings = mockRecentBookings.filter(b => b.status === 'cancelled').length;

  const totalRevenue = mockRecentBookings.reduce((sum, booking) => sum + booking.totalAmount, 0);
  const averageBookingValue = totalRevenue / totalBookings;

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('vi-VN', {
      style: 'currency',
      currency: 'VND',
      minimumFractionDigits: 0,
    }).format(amount);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'confirmed':
        return 'bg-blue-100 text-blue-800';
      case 'ongoing':
        return 'bg-yellow-100 text-yellow-800';
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'cancelled':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'confirmed':
        return 'Đã xác nhận';
      case 'ongoing':
        return 'Đang sử dụng';
      case 'completed':
        return 'Hoàn thành';
      case 'cancelled':
        return 'Đã hủy';
      default:
        return status;
    }
  };

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Tổng đơn đặt</CardTitle>
          <svg
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth="2"
            className="h-4 w-4 text-muted-foreground"
          >
            <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
            <circle cx="9" cy="7" r="4" />
            <path d="m22 21-3-3m0 0a3 3 0 1 1-4.242-4.242 3 3 0 0 1 4.242 4.242Z" />
          </svg>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold" style={{color: '#00D166'}}>{totalBookings}</div>
          <p className="text-xs text-muted-foreground">
            Gần đây
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Đơn hoàn thành</CardTitle>
          <svg
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth="2"
            className="h-4 w-4 text-muted-foreground"
          >
            <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
            <path d="m9 11 3 3L22 4" />
          </svg>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold" style={{color: '#00D166'}}>{completedBookings}</div>
          <p className="text-xs text-muted-foreground">
            {Math.round((completedBookings / totalBookings) * 100)}% tổng số
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Đơn đang sử dụng</CardTitle>
          <svg
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth="2"
            className="h-4 w-4 text-muted-foreground"
          >
            <circle cx="12" cy="12" r="10" />
            <path d="M8 14s1.5 2 4 2 4-2 4-2" />
            <line x1="9" y1="9" x2="9.01" y2="9" />
            <line x1="15" y1="9" x2="15.01" y2="9" />
          </svg>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold" style={{color: '#00D166'}}>{ongoingBookings}</div>
          <p className="text-xs text-muted-foreground">
            Đang hoạt động
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Giá trị trung bình</CardTitle>
          <svg
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth="2"
            className="h-4 w-4 text-muted-foreground"
          >
            <path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6" />
          </svg>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold" style={{color: '#00D166'}}>{formatCurrency(averageBookingValue)}</div>
          <p className="text-xs text-muted-foreground">
            Mỗi đơn đặt
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
