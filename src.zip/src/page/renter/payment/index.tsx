import DoPayment from "./components/do-payment";

export default function Payment() {
  return (
    <div>
      <DoPayment />
    </div>
  );
}
