import HeaderLite from "@/components/headerLite";
import DoPayment from "./components/do-payment";

export default function Payment() {
  return (
    <div>
      <HeaderLite />
      <DoPayment />
    </div>
  );
}
