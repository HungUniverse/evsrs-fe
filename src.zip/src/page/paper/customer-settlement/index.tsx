import { useEffect, useMemo, useState } from "react";
import { useParams } from "react-router-dom";
import { toast } from "sonner";

import { orderBookingAPI } from "@/apis/order-booking.api";

import type { OrderBookingDetail } from "@/@types/order/order-booking";

import PartiesSummary from "../hand-over-inspection/components/PartiesSummary";
import CarInfo from "./components/car-info";
import SettlementViewCustomer from "./components/settlement-view";
import SettlementPaymentQR from "./components/settle-payment-qr";
import InspectionImagesByOrder from "../return-settlement/components/inspection-image";
import type { ReturnSettlement } from "@/@types/order/return-settlement";
import { returnSettlementAPI } from "@/apis/return-settlement.api";

export default function CustomerSettlementPage() {
  const { orderId } = useParams<{ orderId: string }>();

  const [order, setOrder] = useState<OrderBookingDetail | null>(null);
  const [settlement, setSettlement] = useState<ReturnSettlement | null>(null);
  const [loading, setLoading] = useState(true);

  const title = useMemo(() => "BIÊN BẢN THANH TOÁN GIAO XE", []);

  useEffect(() => {
    (async () => {
      if (!orderId) return;
      setLoading(true);
      try {
        const [o, s] = await Promise.all([
          orderBookingAPI.getById(orderId),
          returnSettlementAPI.getByOrderId(orderId),
        ]);

        setOrder(o.data.data);
        setSettlement(s);
      } catch {
        toast.error("Không tải được dữ liệu thanh toán");
      } finally {
        setLoading(false);
      }
    })();
  }, [orderId]);

  if (loading) return <div>Loading...</div>;
  if (!order) return <div>Chưa có biên bản trả xe.</div>;
  return (
    <div className="container mx-auto py-8 space-y-10 max-w-5xl px-4">
      <div className="text-center space-y-3">
        <h1 className="text-xl font-bold uppercase">
          CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM
        </h1>
        <h2 className="text-xl font-bold uppercase">
          Độc lập – Tự do – Hạnh phúc
        </h2>
        <div className="text-lg">---------------------------------</div>
        <h3 className="text-2xl font-bold uppercase text-gray-800">{title}</h3>
      </div>

      <PartiesSummary order={order} />

      <CarInfo
        car={order.carEvs}
        orderId={orderId}
        startAt={order.startAt}
        endAt={order.endAt}
      />

      <InspectionImagesByOrder
        showHandover={true}
        showReturn={true}
        sideBySide={true}
      />

      {settlement ? (
        <SettlementViewCustomer data={settlement} />
      ) : (
        "Không tìm thấy biên bản thanh toán."
      )}

      {settlement &&
        settlement.id &&
        order.status !== "COMPLETED" &&
        order.paymentStatus !== "COMPLETED" && (
          <SettlementPaymentQR
            settlementId={settlement.id}
            orderBookingId={orderId}
          />
        )}
    </div>
  );
}
